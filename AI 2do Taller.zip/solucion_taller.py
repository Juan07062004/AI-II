﻿# ============================================================
# SESION 2 - TENSOR DE COLOR Y ANALISIS ESTADISTICO - SOLUCION
# ============================================================
import cv2
import numpy as np
import matplotlib.pyplot as plt

# ------------------------------------------------------------
# TALLER ANALITICO 1 - Punto 1 (demostracion)
# ------------------------------------------------------------
imagen = np.zeros((1080, 1920, 3), dtype=np.uint8)   # foto 1920x1080
recorte = imagen[100:200, 300:400, 1]               # [filas, columnas, canal]
print('Shape de recorte:', recorte.shape)            # -> (100, 100)

# ------------------------------------------------------------
# TALLER LABORATORIO 1 - Conversion a escala de grises
# ------------------------------------------------------------
# 1. Pixel amarillo intenso en formato BGR (Azul=0, Verde=255, Rojo=255)
pixel = np.array([0, 255, 255], dtype=np.uint8)

# 2. Valor de gris con la formula ponderada (producto punto, orden BGR)
W = np.array([0.114, 0.587, 0.299])                  # pesos [B, G, R]
Y = np.dot(pixel.astype(np.float64), W)               # 0.114*0 + 0.587*255 + 0.299*255
print(f'Valor matematico exacto: {Y}')                # -> 225.93
print(f'Valor de gris final (int): {int(round(Y))}')  # -> 226

# 4. Verificacion con OpenCV sobre una imagen real
imagen_real = cv2.imread('foto_demo.jpg')
img_gris = cv2.cvtColor(imagen_real, cv2.COLOR_BGR2GRAY)
print('Verificacion cv2.cvtColor OK, shape:', img_gris.shape)

# ------------------------------------------------------------
# TALLER LABORATORIO 2 - Analisis estadistico (histogramas)
# ------------------------------------------------------------
# 1. Cargar imagen RGB
imagen = cv2.imread('foto_demo.jpg')

# 2. Separar en 3 canales (OpenCV usa orden BGR)
canal_b = imagen[:, :, 0]
canal_g = imagen[:, :, 1]
canal_r = imagen[:, :, 2]

# 3. Histograma de cada canal
hist_b = cv2.calcHist([canal_b], [0], None, [256], [0, 256])
hist_g = cv2.calcHist([canal_g], [0], None, [256], [0, 256])
hist_r = cv2.calcHist([canal_r], [0], None, [256], [0, 256])

# 4. Graficar los tres histogramas superpuestos
plt.figure(figsize=(10, 5))
plt.plot(hist_b, color='blue',   label='Canal Azul')
plt.plot(hist_g, color='green',  label='Canal Verde')
plt.plot(hist_r, color='red',    label='Canal Rojo')
plt.title('Distribucion de Intensidades por Canal')
plt.xlabel('Valor del Pixel (0-255)')
plt.ylabel('Frecuencia (Cantidad de pixeles)')
plt.legend()
plt.grid(alpha=0.3)
plt.savefig('histograma_demo.png', dpi=110, bbox_inches='tight')
plt.show()

# 5. Conclusion: color dominante = canal con mayor media
medias = {'AZUL': canal_b.mean(), 'VERDE': canal_g.mean(), 'ROJO': canal_r.mean()}
for color, media in medias.items():
    print(f'Media {color}: {media:.1f}')
dominante = max(medias, key=medias.get)
print(f'CONCLUSION: el color dominante en la iluminacion es el {dominante}')
